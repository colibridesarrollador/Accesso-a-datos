package ejerciciosJSON;

import java.util.ArrayList;
import java.util.List;

public class Libros {
	
	private List<Libro> libros = null;
	
	public Libros() {
		
	}

	public List<Libro> getLibros() {
		if (null == libros) {
			libros = new ArrayList<Libro>();
		}
		return libros;
	}

	public void setLibros(List<Libro> libros) {
		this.libros = libros;
	}

	@Override
	public String toString() {
		return "Libros [libros=" + libros + "]";
	}
}