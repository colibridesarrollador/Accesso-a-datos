package ejerciciosJSON;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Clase ejemplo JSON
 * 
 * @author jrico
 *
 */
public class EjerciciosJSON {

	/**
	 * Serializa un objeto JAVA en un String en formato json
	 * 
	 * @param data Object
	 * @return String
	 */
	public String fromObjetToString(Libros data) {
		String json = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			json = mapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return json;

	}

	/**
	 * Deserializa un string en formato JSON almacenado en un fichero, en un objeto
	 * JAVA
	 * 
	 * @param pathname
	 * @return Object
	 */
	public Libros fromFileToObject(String pathname) {
		Libros data = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			data = mapper.readValue(new File(pathname), Libros.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return data;

	}

	/**
	 * Deserializa un string en formato JSON en un objeto JAVA
	 * 
	 * @param json
	 * @return Object
	 */
	public Libros fromStringToObject(String json) {
		Libros data = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			data = mapper.readValue(json, Libros.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return data;

	}

	public static void main(String[] args) {
		FileWriter writer = null;
		BufferedWriter bufferedWriter = null;
		try {
			//Crear libros
			Libros libros = new Libros();
			libros.getLibros().add(new Libro("1980", "El Capote", "Nikolai Gogol"));
			libros.getLibros().add(new Libro("2008", "El Sanador de Caballo", "Gonzalo Giner"));
			libros.getLibros().add(new Libro("1981", "El Nombre de la Rosa", "Umberto Eco"));

			// Serializo el objeto Libros a String
			EjerciciosJSON example = new EjerciciosJSON();
			String json = example.fromObjetToString(libros);
			System.out.println();
			System.out.println("De JAVA a JSON ");
			System.out.println(json);
			
			// Serializo el String en un objeto java
			Libros librosAux = example.fromStringToObject(json);
			System.out.println();
			System.out.println("De JSON a JAVA ");
			System.out.println(librosAux);
						
			// Guardar json a disco
			File file = new File("src/libro.json");
			if (!file.exists()) {
				file.createNewFile();
			}
			writer = new FileWriter(file);
			bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(json);
			bufferedWriter.flush();
			
			// Deserializo de fichero a objeto java
			librosAux = (Libros) example.fromFileToObject("src/libro.json");
			System.out.println();
			System.out.println("De fichero a JAVA ");
			System.out.println(librosAux);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != bufferedWriter) {
				try {
					bufferedWriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (null != writer) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

}