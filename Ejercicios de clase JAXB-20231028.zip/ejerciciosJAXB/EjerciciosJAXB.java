package ejerciciosJAXB;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.List;

import generated.Libros;
import generated.Libro;


import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;


public class EjerciciosJAXB {
	

	public Libros abrirXMLJAXB(String ficheroXML) throws JAXBException{
		Libros misLibros;
		try {
			File fichero = new File(ficheroXML); // //Creamos el objeto File a partir del nombre del fichero pasado como parametro
			
			JAXBContext contexto = JAXBContext.newInstance(Libros.class); //Creamos una instancia JAXB		
			Unmarshaller u = contexto.createUnmarshaller(); // Creamos un objeto Unmarsheller para pasar la informacion del fichero a un objeto			
			
			misLibros = (Libros) u.unmarshal(fichero); // Deserializa (unmarshal) el fichero y guardamos la informacion en un objeto
			
			return misLibros;
		} catch (JAXBException ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public String recorrerJAXB(Libros misLibros){
		String resultado = "";
		
		List<Libro> lLibros = misLibros.getLibro(); // Creamos una lista con objetos de tipo libro a partir del metodo generado en la clase Libros

		for(int i=0; i<lLibros.size(); i++){
			resultado= resultado + "\n " +"Publicado en: " + lLibros.get(i).getPublicadoEn();
			resultado= resultado + "\n " +"El T�tulo es: " + lLibros.get(i).getTitulo();
			resultado= resultado + "\n " +"El Autor es: " + lLibros.get(i).getAutor();
			resultado= resultado + "\n " +"El Precio es: " + lLibros.get(i).getPrecio();
			resultado= resultado + "\n " +"La Editorial es: " + lLibros.get(i).getEditorial();
			resultado = resultado +"\n ------------(Pasamos al siguiente Libro)-----------\n";
		}
		return resultado;
	}
	
	public void modificarTituloLibro(Libros misLibros, String titulo, String tituloNuevo){
		//Crea una lista con objetos de tipo libro.
		List<Libro> lLibros = misLibros.getLibro();
		//Recorre la lista para sacar los valores.
		for(Libro libro: lLibros){
			if (libro.getTitulo().equals(titulo)){
				libro.setTitulo(tituloNuevo);
			}
		}
	}

	public void modificarNombreAutor(Libros misLibros, String autor, String autorNuevo){
		//Crea una lista con objetos de tipo libro.
		List<Libro> lLibros = misLibros.getLibro();
		//Recorre la lista para sacar los valores.
		for(Libro libro: lLibros){
			if (libro.getAutor().equals(autor)){
				libro.setAutor(autorNuevo);
			}
		}
	}
	
	public void modificarFechaLibro(Libros misLibros, String titulo, String anno){
		//Crea una lista con objetos de tipo libro.
		List<Libro> lLibros = misLibros.getLibro();
		//Recorre la lista para sacar los valores.
		for(Libro libro: lLibros){
			if (libro.getTitulo().equals(titulo)){
				libro.setPublicadoEn(anno);
			}
		}
	}

	public String mostrarLibrosAutor(Libros misLibros, String autor){
		StringBuilder resultado = new StringBuilder();
		//Crea una lista con objetos de tipo libro.
		List<Libro> lLibros = misLibros.getLibro();
		//Recorre la lista para sacar los valores.
		for(Libro libro: lLibros){
			if (autor.equals(libro.getAutor())){
				resultado.append("\n " +"Publicado en: " + libro.getPublicadoEn());
				resultado.append("\n " +"El T�tulo es: " + libro.getTitulo());
				resultado.append("\n " +"El Autor es: " + libro.getAutor());
				resultado.append("\n " +"El Precio es: " + libro.getPrecio());
				resultado.append("\n " +"La Editorial es: " + libro.getEditorial());
				resultado.append("\n ----------------------------");
			}
		}
		return resultado.toString();
	}
	
	public String mostrarLibrosSiglo(Libros misLibros, int siglo){
		StringBuilder resultado = new StringBuilder();		
		List<Libro> lLibros = misLibros.getLibro(); // Guardamos en una lista los libros

		int anno = 0;
		for(Libro libro: lLibros){
			anno = Integer.parseInt(libro.getPublicadoEn());
			int s = (int)(anno / 100) + 1;
			if (s == siglo){
				resultado.append("\n " +"Publicado en: " + libro.getPublicadoEn());
				resultado.append("\n " +"El T�tulo es: " + libro.getTitulo());
				resultado.append("\n " +"El Autor es: " + libro.getAutor());
				resultado.append("\n " +"El Precio es: " + libro.getPrecio());
				resultado.append("\n " +"La Editorial es: " + libro.getEditorial());
				resultado.append("\n ----------------------------");
			}
		}
		return resultado.toString();
	}
	
	public void crearXMLJAXB(String ficheroXML, Libros misLibros) throws JAXBException, IOException{
		Writer w = null;
		try {
			// Creamos el contexto e instanciamos el marshaller
			JAXBContext context = JAXBContext.newInstance(Libros.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			w = new FileWriter(ficheroXML);
			m.marshal(misLibros, w);
		} catch (JAXBException | IOException ex) {
			ex.printStackTrace();
			throw ex;
		}
		finally {
			try {
				w.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	
	/**
	 * M�todo principal
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		EjerciciosJAXB helper = new EjerciciosJAXB();
		Libros misLibros = helper.abrirXMLJAXB("files/libroscompleto.xml"); // Recibimos el fichero .xml y se guarda en un objeto de tipo Libros (una lista de objetos de tipo Libro)
		System.out.println("Unmarshal realizado correctamente");
		
		// Recorremos la lista de libros obtenidos del fichero y se muestra por pantalla
		String salidaFichero = helper.recorrerJAXB(misLibros);
		System.out.println(salidaFichero);
		
		// A�adir un Libro
		// Definimos los valores que se guardaran en el nuevo objeto Libro
		String  titulo = "Me encanta Acceso a Datos (Relativamente)", 
				autor = "Jesus Profesor", 
				publicado_en = "2023", 
				editorial = "Editorial Clase";		
		Double  precio = 19.99;
		
		Libro miLibro = new Libro();
		miLibro.setAutor(autor);
		miLibro.setTitulo(titulo);
		miLibro.setPublicadoEn(publicado_en);
		miLibro.setEditorial(editorial);
		miLibro.setPrecio(precio);
		misLibros.getLibro().add(miLibro);
		
		// Recorremos de nuevo la lista de libros para comprobar que se ha a�adido el nuevo libro
		salidaFichero = helper.recorrerJAXB(misLibros);
		System.out.println("Proceso 1: \n " + salidaFichero);
			
		// Mostrar Libros de un Siglo
		salidaFichero = helper.mostrarLibrosSiglo(misLibros, 20);
		System.out.println(salidaFichero);
		
		// Mostrar Libros de un Autor
		salidaFichero = helper.mostrarLibrosAutor(misLibros, "Umberto Eco");
		System.out.println(salidaFichero);

		// Modificar T�tulo de Libro
		helper.modificarTituloLibro(misLibros, "El Capote", "Test Title");
		salidaFichero = helper.recorrerJAXB(misLibros);
		System.out.println(salidaFichero);

		// Modificar Autor de Libro
		helper.modificarNombreAutor(misLibros, "Autor de Prueba", "Test Author");
		salidaFichero = helper.recorrerJAXB(misLibros);
		System.out.println(salidaFichero);
		
		// Modificar Fecha de Libro
		helper.modificarFechaLibro(misLibros, "Test Title", "2015");
		salidaFichero = helper.recorrerJAXB(misLibros);
		System.out.println(salidaFichero);
		
		//Guardar fichero final modificado
		helper.crearXMLJAXB("files/librosNuevo.xml", misLibros);
	}

}